<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bejelentkezés</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            overflow: hidden;
            width: 100vw;
            height: 100vh;
            overflow-x: hidden;
            font-family: "Inter", sans-serif;
            color: #972929ff;
            background: #000000ff;
        }
        .background {
            position: fixed;
            inset: 0;
            filter: blur(8px) brightness(1.1);
            transform: scale(1.01);
            z-index: 0;
        }
        .form-container {
            position: relative;
            z-index: 3;
            max-width: 500px;
            height: 50vh;
            margin: 120px auto 0;
            background: rgba(91, 52, 52, 0.75);
            border-radius: 40px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 5vh;
            color: #c71c1cff;
            font-size: 42px;
        }

        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group input {
            margin-bottom: 2vh;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 15px;
            background: rgba(180, 48, 48, 0.8);
            color: #a82424ff;
            font-size: 19px;
        }
        .form-group input:focus {
            outline: none;
            box-shadow: 0 0 5px #000000ff;
        }
        .form-group input::placeholder {
            color: #000000ff;
        }
        .btnBejel {
            width: 80%;
            padding: 12px;
            background-color: #c02525ff;
            border: none;
            border-radius: 12px;
            color: #000000ff;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 30px;
        }
        .btnRegiszt {
            width: 60%;
            position: relative;
            padding: 12px;
            background: #b62121ff;
            border: none;
            border-radius: 12px;
            color: #000000e9;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btnRegiszt:hover {
            transition: 0.5s;
            width: 63%;
        }
        .btnBejel:hover {
            transition: 0.5s;
            width: 83%;
        }

        .gombok {
            margin-top: 3vh;
            text-align: center;
        }

        .megjelenito {
            user-select: none;
            float: right;
            margin-right: 1.4vh;
            margin-top: -6vh;
            position: relative;
            z-index: 2;
            color: #000000ff;
            font-size: 25px;
        }
        
        .megjelenito:hover {
            cursor: pointer;
        }

        .error-message {
            background: rgba(110, 57, 57, 0.7);
            color: white;
            padding: 10px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 15px;
        }

      
    </style>
</head>
<body>
    <div class="background"></div>
    <div class="form-container">
        <h2>Bejelentkezés</h2>
        
        <?php
        // PHP hibakezelés - üzenet megjelenítése
        session_start();
        if (isset($_SESSION['login_error'])) {
            echo '<div class="error-message">' . htmlspecialchars($_SESSION['login_error']) . '</div>';
            unset($_SESSION['login_error']);
        }
        ?>
        
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <div class="form-group">
                <input type="text" placeholder="Felhasználónév vagy Email" id="identifier" name="identifier" required value="<?php echo isset($_POST['identifier']) ? htmlspecialchars($_POST['identifier']) : ''; ?>">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Jelszó" id="password" name="password" required>
                <span class="megjelenito" onclick="myFunction()">👁</span>
            </div>
            <div class="gombok">
                <button type="submit" name="login" class="btnBejel">Bejelentkezés</button>
                <button type="button" class="btnRegiszt" onclick="window.location.href='../php/regiszt.php'">Regisztráció</button>
            </div>
        </form>
    </div>

    <script>
        function myFunction() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
    <script src="../js/script.js"></script>
    
    <?php
    // PHP bejelentkezési logika
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
        $identifier = trim($_POST['identifier']);
        $password = trim($_POST['password']);
        
        
        session_start();
        if ($identifier === "admin" && $password === "admin123") {
            $_SESSION['user_id'] = 1;
            $_SESSION['username'] = $identifier;
            $_SESSION['logged_in'] = true;
            header("Location: ../html/főoldal.html");
            exit();
        } else {
            $_SESSION['login_error'] = "Hibás felhasználónév/email vagy jelszó!";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
    }
    ?>
</body>
</html>