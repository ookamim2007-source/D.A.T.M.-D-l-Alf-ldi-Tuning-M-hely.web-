<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            overflow: hidden;
            width: 100vw;
            height: 100vh;
            overflow-x: hidden;
            font-family: "Inter", sans-serif;
            color: #fff;
            background: #000;
        }
        .background {
            position: fixed;
            inset: 0;
            background: url("../Kepek/pexels-albinberlin-919073.png") center/cover no-repeat;
            filter: blur(8px) brightness(1.1);
            transform: scale(1.01);
            z-index: 0;
        }
        .form-container {
            position: relative;
            z-index: 3;
            max-width: 500px;
            height: auto;
            min-height: 65vh;
            margin: 80px auto 0;
            background: rgba(90, 90, 90, 0.75);
            border-radius: 40px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 5vh;
            color: #ffffff;
            font-size: 42px;
        }

        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group input {
            margin-bottom: 2vh;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 15px;
            background: rgba(50, 50, 50, 0.8);
            color: #fff;
            font-size: 19px;
        }
        .form-group input:focus {
            outline: none;
            box-shadow: 0 0 5px #adadad;
        }
        .form-group input::placeholder {
            color: #acacac;
        }
        .btnRegiszt {
            width: 80%;
            padding: 12px;
            background-color: #202020;
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 30px;
        }
        .btnBejel {
            width: 60%;
            position: relative;
            padding: 12px;
            background: #202020;
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btnBejel:hover {
            transition: 0.5s;
            width: 63%;
        }
        .btnRegiszt:hover {
            transition: 0.5s;
            width: 83%;
        }

        .gombok {
            margin-top: 3vh;
            text-align: center;
        }

        .megjelenito {
            user-select: none;
            float: right;
            margin-right: 1.4vh;
            margin-top: -6vh;
            position: relative;
            z-index: 2;
            color: #adadad;
            font-size: 25px;
        }
        
        .megjelenito:hover {
            cursor: pointer;
        }

        .error-message {
            background: rgba(255, 0, 0, 0.7);
            color: white;
            padding: 10px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 15px;
        }

        .success-message {
            background: rgba(0, 255, 0, 0.7);
            color: white;
            padding: 10px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="background"></div>
    <div class="form-container">
        <h2>Regisztráció</h2>
        
        <?php
        session_start();
        
        // Üzenetek megjelenítése
        if (isset($_SESSION['error_message'])) {
            echo '<div class="error-message">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
            unset($_SESSION['error_message']);
        }
        
        if (isset($_SESSION['success_message'])) {
            echo '<div class="success-message">' . htmlspecialchars($_SESSION['success_message']) . '</div>';
            unset($_SESSION['success_message']);
        }
        ?>
        
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <div class="form-group">
                <input type="email" placeholder="Email" id="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            <div class="form-group">
                <input type="text" placeholder="Felhasználónév" id="username" name="username" required value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Jelszó" id="password" name="password" required>
                <span class="megjelenito" onclick="togglePassword('password', this)">👁</span>
            </div>
            <div class="form-group">
                <input type="password" placeholder="Jelszó még egyszer" id="password2" name="password2" required>
                <span class="megjelenito" onclick="togglePassword('password2', this)">👁</span>
            </div>
            <div class="gombok">
                <button type="submit" name="register" class="btnRegiszt">Regisztráció</button>
                <button type="button" class="btnBejel" onclick="window.location.href='../php/bejel.php'">Bejelentkezés</button>
            </div>   
        </form>
    </div>

    <script>
        function togglePassword(inputId, element) {
            var x = document.getElementById(inputId);
            if (x.type === "password") {
                x.type = "text";
                element.textContent = "🙈";
            } else {
                x.type = "password";
                element.textContent = "👁";
            }
        }
    </script>
    <script src="../js/script.js"></script>
    
    <?php
    // Regisztrációs logika
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
        $email = trim($_POST['email']);
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $password2 = $_POST['password2'];
        
        $errors = [];
        
        // Email validáció
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Érvénytelen email cím!";
        }
        
        // Felhasználónév validáció
        if (strlen($username) < 3) {
            $errors[] = "A felhasználónévnek legalább 3 karakter hosszúnak kell lennie!";
        }
        
        // Jelszó validáció
        if (strlen($password) < 6) {
            $errors[] = "A jelszónak legalább 6 karakter hosszúnak kell lennie!";
        }
        
        // Jelszó egyezés ellenőrzése
        if ($password !== $password2) {
            $errors[] = "A két jelszó nem egyezik!";
        }
        
        // Ha nincs hiba, folytatjuk a regisztrációt
        if (empty($errors)) {
            // Adatbázis kapcsolat (cseréld le a saját adataidra)
            /*
            $host = 'localhost';
            $dbname = 'your_database';
            $dbusername = 'your_username';
            $dbpassword = 'your_password';
            
            try {
                $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $dbusername, $dbpassword);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                // Ellenőrizzük, hogy létezik-e már a felhasználónév vagy email
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
                $stmt->execute(['username' => $username, 'email' => $email]);
                
                if ($stmt->fetch()) {
                    $_SESSION['error_message'] = "Ez a felhasználónév vagy email cím már regisztrálva van!";
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                }
                
                // Jelszó hashelése
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Új felhasználó beszúrása
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, created_at) VALUES (:username, :email, :password, NOW())");
                $stmt->execute([
                    'username' => $username,
                    'email' => $email,
                    'password' => $hashedPassword
                ]);
                
                $_SESSION['success_message'] = "Sikeres regisztráció! Most már bejelentkezhetsz.";
                header("Location: ../html/bejelentkezes.html");
                exit();
                
            } catch(PDOException $e) {
                $_SESSION['error_message'] = "Adatbázis hiba: " . $e->getMessage();
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            }
            */
            
            // DEMO verzió (később cseréld ki a fenti adatbázis kódra)
            // Ez csak bemutató célú, élesben ne használd!
            session_start();
            
            // Itt tárolhatnád fájlban vagy session-ben az adatokat
            // De demo célból csak kiírjuk a sikert
            
            $_SESSION['success_message'] = "Sikeres regisztráció! (DEMO mód) Most már bejelentkezhetsz.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
            
        } else {
            // Hibák megjelenítése
            $_SESSION['error_message'] = implode(" ", $errors);
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
    }
    ?>
</body>
</html>